function iniciar() {
    alert("Vamos começar a sequência mágica!");
    // Aqui você pode redirecionar ou iniciar a atividade, por exemplo:
    // window.location.href = "atividade.html";
  }
  